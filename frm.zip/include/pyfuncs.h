#ifndef REAL_FRAMEWORK_PYFUNCS_H_
#define REAL_FRAMEWORK_PYFUNCS_H_

void HelloPy();
void simple_cnn();

#endif
